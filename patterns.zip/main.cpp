#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"Enter no. of rows:";
    cin>>n;
    for(int r=0; r<n; r++){
        for(int c=0; c<r+1; c++){
            cout<<c+1<<" " ;
        }
        //Ye me bhul jata hu
        cout<<endl;
    }
}